/* eslint-disable */
/**
 * Generated `api` utility.
 *
 * THIS CODE IS AUTOMATICALLY GENERATED.
 *
 * To regenerate, run `npx convex dev`.
 * @module
 */

import type {
  ApiFromModules,
  FilterApi,
  FunctionReference,
} from "convex/server";
import type * as assessments from "../assessments.js";
import type * as auth from "../auth.js";
import type * as content from "../content.js";
import type * as emergency from "../emergency.js";
import type * as http from "../http.js";
import type * as moods from "../moods.js";
import type * as router from "../router.js";
import type * as student from "../student.js";

/**
 * A utility for referencing Convex functions in your app's API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = api.myModule.myFunction;
 * ```
 */
declare const fullApi: ApiFromModules<{
  assessments: typeof assessments;
  auth: typeof auth;
  content: typeof content;
  emergency: typeof emergency;
  http: typeof http;
  moods: typeof moods;
  router: typeof router;
  student: typeof student;
}>;
export declare const api: FilterApi<
  typeof fullApi,
  FunctionReference<any, "public">
>;
export declare const internal: FilterApi<
  typeof fullApi,
  FunctionReference<any, "internal">
>;
